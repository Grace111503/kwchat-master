const p=""+new URL("../pwa-192x192.png",import.meta.url).href;export{p as _};
